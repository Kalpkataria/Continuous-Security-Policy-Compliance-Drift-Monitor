
from compliance.alert_storage import (
    create_alert_table,
    save_alert,
    get_alert_history
)

create_alert_table()

save_alert(
    control="firewall",
    alert_type="Test Security Alert",
    severity="High",
    message="This is a test alert to verify alert management."
)

print("Test alert created successfully!")

alerts = get_alert_history(5)

for alert in alerts:
    print(dict(alert))
