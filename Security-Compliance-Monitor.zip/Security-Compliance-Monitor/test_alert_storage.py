
from compliance.alert_storage import create_alert_table, get_alert_history

create_alert_table()

alerts = get_alert_history()

print("\nSECURITY ALERT HISTORY")

if alerts:
    for alert in alerts:
        print(dict(alert))
else:
    print("No security alerts recorded yet.")
