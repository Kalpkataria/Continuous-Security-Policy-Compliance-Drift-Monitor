
from winotify import Notification, audio
from compliance.alert_storage import create_alert_table, save_alert


def send_alert(title, message, severity="info"):
    try:
        notification = Notification(
            app_id="Security Compliance Monitor",
            title=title,
            msg=message
        )

        if severity == "critical":
            notification.set_audio(audio.Default, loop=False)

        notification.show()
        print(f"[ALERT] {title}: {message}")

    except Exception as error:
        print(f"Notification error: {error}")


def record_and_notify(control, alert_type, severity, message):
    # Save the alert in SQLite
    try:
        save_alert(control, alert_type, severity, message)
        print(f"[DATABASE] Alert saved for {control}")
    except Exception as error:
        print(f"Alert database error: {error}")

    # Show Windows notification
    send_alert(alert_type, message, severity)


def check_security_alerts(report):

    create_alert_table()

    for item in report:
        control = item["control"]
        status = item["status"]
        drift = item["drift_status"]
        severity = item["severity"]

        if drift == "DRIFT_DETECTED":
            record_and_notify(
                control,
                "Security Drift Detected",
                "critical",
                f"{control} changed from PASS to FAIL. Severity: {severity}"
            )

        elif drift == "RECOVERED":
            record_and_notify(
                control,
                "Security Control Recovered",
                "info",
                f"{control} is now compliant."
            )

        elif status == "FAIL" and drift == "NO_PREVIOUS_SCAN":
            record_and_notify(
                control,
                "Initial Security Failure",
                "critical",
                f"{control} is non-compliant. Severity: {severity}"
            )
