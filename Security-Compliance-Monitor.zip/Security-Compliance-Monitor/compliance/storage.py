
import sqlite3
from pathlib import Path
from datetime import datetime


BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "compliance.db"


def initialize_database():
    """Create database tables if they do not exist."""

    with sqlite3.connect(DB_PATH) as conn:

        conn.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                scan_id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_time TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS control_results (
                result_id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL,
                control TEXT NOT NULL,
                status TEXT NOT NULL,
                severity TEXT,
                evidence TEXT,
                recommendation TEXT,
                previous_status TEXT,
                drift_status TEXT,
                FOREIGN KEY (scan_id) REFERENCES scans(scan_id)
            )
        """)

        conn.commit()


def get_previous_status(conn, control):
    """Find the latest reliable PASS or FAIL result."""

    result = conn.execute("""
        SELECT cr.status
        FROM control_results cr
        JOIN scans s ON cr.scan_id = s.scan_id
        WHERE cr.control = ?
          AND cr.status IN ('PASS', 'FAIL')
        ORDER BY s.scan_id DESC, cr.result_id DESC
        LIMIT 1
    """, (control,)).fetchone()

    return result[0] if result else None


def detect_drift(previous, current):
    """Compare previous and current compliance status."""

    if current not in ("PASS", "FAIL"):
        return "UNKNOWN"

    if previous is None:
        return "NO_PREVIOUS_SCAN"

    if previous == "PASS" and current == "FAIL":
        return "DRIFT_DETECTED"

    if previous == "FAIL" and current == "PASS":
        return "RECOVERED"

    return "NO_CHANGE"


def save_scan(report):
    """Save current scan and detect configuration drift."""

    initialize_database()

    with sqlite3.connect(DB_PATH) as conn:

        cursor = conn.execute("""
            INSERT INTO scans (scan_time)
            VALUES (?)
        """, (datetime.now().astimezone().isoformat(),))

        scan_id = cursor.lastrowid

        updated_report = []

        for item in report:

            previous = get_previous_status(
                conn,
                item["control"]
            )

            drift = detect_drift(
                previous,
                item["status"]
            )

            conn.execute("""
                INSERT INTO control_results (
                    scan_id,
                    control,
                    status,
                    severity,
                    evidence,
                    recommendation,
                    previous_status,
                    drift_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                scan_id,
                item["control"],
                item["status"],
                item["severity"],
                item["evidence"],
                item["recommendation"],
                previous,
                drift
            ))

            updated_item = item.copy()
            updated_item["previous_status"] = previous
            updated_item["drift_status"] = drift

            updated_report.append(updated_item)

        conn.commit()

    return scan_id, updated_report


def get_scan_history(limit=10):
    """Retrieve recent scans with compliance statistics."""

    initialize_database()

    with sqlite3.connect(DB_PATH) as conn:

        conn.row_factory = sqlite3.Row

        rows = conn.execute("""
            SELECT
                s.scan_id,
                s.scan_time,

                COUNT(cr.result_id) AS total,

                SUM(
                    CASE WHEN cr.status = 'PASS'
                    THEN 1 ELSE 0 END
                ) AS passed,

                SUM(
                    CASE WHEN cr.status = 'FAIL'
                    THEN 1 ELSE 0 END
                ) AS failed,

                SUM(
                    CASE WHEN cr.status = 'ERROR'
                    THEN 1 ELSE 0 END
                ) AS errors

            FROM scans s

            LEFT JOIN control_results cr
                ON s.scan_id = cr.scan_id

            GROUP BY s.scan_id, s.scan_time

            ORDER BY s.scan_id DESC

            LIMIT ?
        """, (limit,)).fetchall()

    history = []

    for row in rows:

        item = dict(row)

        # Handle scans with no control results
        item["total"] = item["total"] or 0
        item["passed"] = item["passed"] or 0
        item["failed"] = item["failed"] or 0
        item["errors"] = item["errors"] or 0

        # Only PASS and FAIL controls are assessed
        item["assessed"] = (
            item["passed"] + item["failed"]
        )

        # Exclude ERROR controls from compliance score
        item["score"] = (
            round(
                item["passed"] / item["assessed"] * 100,
                1
            )
            if item["assessed"] else 0
        )

        history.append(item)

    return history
