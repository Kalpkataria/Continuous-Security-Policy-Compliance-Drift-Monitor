
# ============================================================
# WINDOWS SECURITY COMPLIANCE - REMEDIATION GUIDANCE
# ============================================================


# 1. CONTROL-BASED REMEDIATION
# Used when an alert does not have specific incident guidance.

REMEDIATION_GUIDANCE = {

    "firewall": {
        "risk": (
            "Windows Firewall may not be properly configured, "
            "increasing the risk of unauthorized network access."
        ),
        "actions": [
            "Open Windows Security and review Firewall settings.",
            "Check the Domain, Private, and Public firewall profiles.",
            "Investigate possible unauthorized configuration changes.",
            "Restore the approved firewall configuration if necessary.",
            "Review inbound and outbound firewall rules.",
            "Run a fresh compliance scan."
        ],
        "verification": "All required firewall profiles must be enabled."
    },

    "defender_antivirus": {
        "risk": (
            "Microsoft Defender Antivirus is not enabled or "
            "may not be providing adequate malware protection."
        ),
        "actions": [
            "Check Microsoft Defender service and health status.",
            "Review Microsoft Defender security notifications.",
            "Investigate possible unauthorized configuration changes.",
            "Restore the approved antivirus configuration.",
            "Run a full security scan.",
            "Run a fresh compliance scan."
        ],
        "verification": "Microsoft Defender Antivirus status must return to PASS."
    },

    "defender_realtime": {
        "risk": (
            "Real-time protection may be disabled, allowing "
            "malware to execute without immediate detection."
        ),
        "actions": [
            "Open Windows Security.",
            "Navigate to Virus and threat protection settings.",
            "Check the Real-time protection status.",
            "Investigate why real-time protection was disabled.",
            "Restore protection according to organizational policy.",
            "Run a fresh compliance scan."
        ],
        "verification": "Real-time protection must be enabled."
    },

    "event_log": {
        "risk": (
            "Windows Event Logging may not be operating correctly, "
            "making security investigations difficult."
        ),
        "actions": [
            "Check the Windows Event Log service.",
            "Review service errors and Windows system events.",
            "Check available disk space and event log configuration.",
            "Restore the logging service using approved procedures.",
            "Verify that new security events are being recorded.",
            "Run a fresh compliance scan."
        ],
        "verification": "Windows Event Log service must be running."
    }
}


# 2. SEVERITY-BASED PRIORITY GUIDANCE

SEVERITY_GUIDANCE = {

    "Critical": (
        "Immediate attention required. Escalate to the security "
        "team and follow the organization's incident response plan."
    ),

    "High": (
        "High priority. Investigate as soon as possible and "
        "escalate if suspicious activity is confirmed."
    ),

    "Medium": (
        "Investigate promptly. Review related logs and monitor "
        "for additional suspicious activity."
    ),

    "Low": (
        "Record the finding and review it during routine "
        "security maintenance."
    )
}


# 3. INCIDENT-SPECIFIC REMEDIATION
# These entries match the alert_type values in simulate_attack.py.

INCIDENT_REMEDIATION = {

    "Unauthorized Firewall Configuration Change": {
        "risk": (
            "An unauthorized firewall change may expose the endpoint "
            "to network attacks."
        ),
        "actions": [
            "Review the affected firewall profile and rules.",
            "Identify who made the configuration change.",
            "Compare settings with the approved security baseline.",
            "Investigate any unexpected inbound or outbound rules.",
            "Restore approved firewall settings if necessary.",
            "Run a compliance scan."
        ],
        "verification": "Firewall settings match the approved security baseline."
    },

    "Malware Detection": {
        "risk": (
            "Malicious software may compromise the endpoint, "
            "steal information, or damage files."
        ),
        "actions": [
            "Identify the malware name and affected file.",
            "Review Microsoft Defender detection details.",
            "Determine whether the malware executed.",
            "Follow incident-response policy for endpoint containment.",
            "Perform approved malware removal or quarantine.",
            "Run a full security scan.",
            "Verify that the endpoint is clean."
        ],
        "verification": "No active malware detection remains."
    },

    "Real-Time Protection Disabled": {
        "risk": (
            "Disabled real-time protection may allow malicious files "
            "to execute without immediate detection."
        ),
        "actions": [
            "Check the Microsoft Defender real-time protection status.",
            "Investigate when and why protection was disabled.",
            "Review related Windows security events.",
            "Check for suspicious processes or recent file activity.",
            "Restore real-time protection according to security policy.",
            "Run a security scan."
        ],
        "verification": "Microsoft Defender real-time protection is enabled."
    },

    "Security Logging Failure": {
        "risk": (
            "Missing security logs can prevent investigators from "
            "identifying suspicious activity."
        ),
        "actions": [
            "Check the Windows Event Log service.",
            "Review service errors and Windows system events.",
            "Check available disk space and log configuration.",
            "Investigate unexpected service interruptions.",
            "Restore the logging service using approved procedures.",
            "Verify that new security events are being recorded."
        ],
        "verification": "Windows Event Log is running and recording events."
    },

    "Suspicious PowerShell Activity": {
        "risk": (
            "PowerShell may be used to execute malicious commands, "
            "download malware, or modify system settings."
        ),
        "actions": [
            "Identify the PowerShell process and parent process.",
            "Review command-line arguments.",
            "Examine PowerShell operational logs.",
            "Identify the user account responsible.",
            "Investigate related files and network connections.",
            "Escalate or isolate the endpoint if malicious activity is confirmed."
        ],
        "verification": (
            "The suspicious activity has been investigated "
            "and contained if necessary."
        )
    },

    "Suspicious Outbound Connection": {
        "risk": (
            "The endpoint may be communicating with an untrusted "
            "external destination."
        ),
        "actions": [
            "Identify the remote IP address and destination port.",
            "Identify the process responsible for the connection.",
            "Review DNS and network activity.",
            "Check the destination against trusted threat intelligence sources.",
            "Investigate whether sensitive data was transmitted.",
            "Block the destination through approved security controls "
            "if confirmed malicious."
        ],
        "verification": (
            "The destination has been investigated and "
            "unauthorized communication has stopped."
        )
    },

    "Repeated Failed Login Attempts": {
        "risk": (
            "Repeated authentication failures may indicate "
            "brute-force or password-spraying activity."
        ),
        "actions": [
            "Identify the source IP address.",
            "Review failed login events and Windows Event ID 4625.",
            "Check whether a successful login followed the failures.",
            "Identify affected user accounts.",
            "Review account lockout and authentication policies.",
            "Apply approved account protection measures.",
            "Monitor for further suspicious login attempts."
        ],
        "verification": (
            "No continuing unauthorized authentication activity is observed."
        )
    },

    "Potentially Unwanted Application": {
        "risk": (
            "An unwanted application may introduce security, "
            "performance, or privacy risks."
        ),
        "actions": [
            "Identify the application and its source.",
            "Review Microsoft Defender detection details.",
            "Check whether the application was installed intentionally.",
            "Determine whether it is approved by the organization.",
            "Uninstall or quarantine it if confirmed unwanted.",
            "Run a security scan."
        ],
        "verification": (
            "The unwanted application is removed or approved."
        )
    }
}


# 4. MAIN REMEDIATION FUNCTION

def get_remediation(control, severity, alert_type=None):

    # First, check for incident-specific remediation.
    guidance = None

    if alert_type:
        guidance = INCIDENT_REMEDIATION.get(alert_type)

    # If no incident-specific guidance exists,
    # use the control-based remediation.
    if guidance is None:
        guidance = REMEDIATION_GUIDANCE.get(control)

    # Default guidance for unknown controls or incidents.
    if guidance is None:
        guidance = {
            "risk": "A security issue requires investigation.",
            "actions": [
                "Review the alert details.",
                "Identify the affected system or setting.",
                "Investigate the possible cause.",
                "Escalate according to the incident response policy.",
                "Verify that the issue has been resolved."
            ],
            "verification": "Confirm that the security issue is resolved."
        }

    # Return remediation information and severity priority.
    return {
        **guidance,
        "priority": SEVERITY_GUIDANCE.get(
            severity,
            "Review and investigate according to organizational policy."
        )
    }
