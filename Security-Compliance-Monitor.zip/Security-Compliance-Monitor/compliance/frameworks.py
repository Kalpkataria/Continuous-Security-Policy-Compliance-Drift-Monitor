
import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
MAPPING_FILE = BASE_DIR / "framework_mapping.json"


def load_framework_mappings():

    with open(MAPPING_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def get_control_mapping(control_name):

    mappings = load_framework_mappings()

    return mappings.get(
        control_name,
        {
            "control_name": control_name,
            "description": "No framework mapping available.",
            "cis_controls": [],
            "nist_controls": [],
            "iso_controls": []
        }
    )


def enrich_report(report):

    enriched_report = []

    for item in report:

        updated_item = item.copy()

        mapping = get_control_mapping(item["control"])

        updated_item["framework_mapping"] = mapping

        enriched_report.append(updated_item)

    return enriched_report


if __name__ == "__main__":

    mappings = load_framework_mappings()

    print("\n===== SECURITY FRAMEWORK MAPPINGS =====\n")

    for control, details in mappings.items():

        print(f"Control: {details['control_name']}")

        print("CIS Controls:")
        for item in details["cis_controls"]:
            print(f"  {item['id']} - {item['name']}")

        print("NIST:")
        for item in details["nist_controls"]:
            print(f"  {item['id']} - {item['name']}")

        print("ISO:")
        for item in details["iso_controls"]:
            print(f"  {item['id']} - {item['name']}")

        print("-" * 50)
