
import sqlite3
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "compliance.db"



def create_alert_table():
    conn = sqlite3.connect(DB_PATH)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            control TEXT NOT NULL,
            alert_type TEXT NOT NULL,
            severity TEXT,
            message TEXT,
            timestamp TEXT NOT NULL,
            status TEXT DEFAULT 'OPEN'
        )
    """)

    # Upgrade existing databases safely
    columns = [
        row[1] for row in
        conn.execute("PRAGMA table_info(alerts)").fetchall()
    ]

    if "status" not in columns:
        conn.execute("""
            ALTER TABLE alerts
            ADD COLUMN status TEXT DEFAULT 'OPEN'
        """)

    conn.commit()
    conn.close()



def save_alert(control, alert_type, severity, message):
    conn = sqlite3.connect(DB_PATH)

    conn.execute("""
        INSERT INTO alerts
        (control, alert_type, severity, message, timestamp)
        VALUES (?, ?, ?, ?, ?)
    """, (
        control,
        alert_type,
        severity,
        message,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))

    conn.commit()
    conn.close()

    
def get_alert_history(limit=20, status=None, severity=None):
    """Retrieve alert history with optional filters."""

    create_alert_table()

    query = "SELECT * FROM alerts WHERE 1=1"
    params = []

    if status:
        query += " AND status = ?"
        params.append(status)

    if severity:
        query += " AND severity = ?"
        params.append(severity)

    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(query, params).fetchall()

    return rows



def update_alert_status(alert_id, new_status):
    """Update the status of an existing security alert."""

    allowed_statuses = ["OPEN", "ACKNOWLEDGED", "RESOLVED"]

    if new_status not in allowed_statuses:
        raise ValueError("Invalid alert status")

    create_alert_table()

    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.execute("""
            UPDATE alerts
            SET status = ?
            WHERE id = ?
        """, (new_status, alert_id))

        return cursor.rowcount > 0
