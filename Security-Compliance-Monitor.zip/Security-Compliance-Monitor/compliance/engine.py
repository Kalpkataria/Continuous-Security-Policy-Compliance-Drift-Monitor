
import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
BASELINE_FILE = BASE_DIR / "baseline.json"


def load_baseline():
    with open(BASELINE_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def extract_actual_value(name, data):
    """Extract the actual setting from collector output."""

    if name == "firewall":
        return data

    if name == "defender_antivirus":
        return data.get("AntivirusEnabled")

    if name == "defender_realtime":
        return data.get("RealTimeProtectionEnabled")

    if name == "event_log":
        return data.get("Status")

    return data


def compare_value(actual, rule):
    """Compare an actual setting against its baseline."""

    expected = rule["expected"]
    comparison = rule.get("comparison", "equals")

    if comparison == "equals":
        return actual == expected

    if comparison == "all_true":
        if not isinstance(actual, list) or not actual:
            return False

        return all(
            profile.get("Enabled") is True
            for profile in actual
        )

    if comparison == "in":
        return actual in expected

    if comparison == "minimum":
        return isinstance(actual, (int, float)) and actual >= expected

    if comparison == "maximum":
        return isinstance(actual, (int, float)) and actual <= expected

    if comparison == "range":
        return (
            isinstance(actual, (int, float))
            and 1 <= actual <= expected
        )

    if comparison == "contains":
        return (
            isinstance(actual, str)
            and str(expected).lower() in actual.lower()
        )

    raise ValueError(f"Unsupported comparison method: {comparison}")


def evaluate_control(name, rule, actual):
    """Evaluate one security control."""

    if actual.get("status") != "OK":
        return {
            "control": name,
            "status": "ERROR",
            "severity": rule["severity"],
            "evidence": actual.get(
                "evidence",
                "Security setting unavailable"
            ),
            "recommendation": rule["recommendation"]
        }

    try:
        data = actual["data"]

        value = extract_actual_value(name, data)

        if value is None:
            raise ValueError("Required security setting was not returned")

        passed = compare_value(value, rule)

        evidence = f"Actual value: {value}; Expected: {rule['expected']}"

        if name == "firewall":
            profile_details = [
                f"{profile.get('Name')}: {profile.get('Enabled')}"
                for profile in data
            ]
            evidence = "; ".join(profile_details)

        return {
            "control": name,
            "status": "PASS" if passed else "FAIL",
            "severity": rule["severity"],
            "evidence": evidence,
            "recommendation": rule["recommendation"]
        }

    except Exception as exc:
        return {
            "control": name,
            "status": "ERROR",
            "severity": rule["severity"],
            "evidence": str(exc),
            "recommendation": rule["recommendation"]
        }


def evaluate_all(scan_results):
    """Evaluate all controls defined in baseline.json."""

    baseline = load_baseline()

    report = []

    for name, rule in baseline.items():

        actual = scan_results.get(name)

        if actual is None:
            actual = {
                "status": "ERROR",
                "evidence": "Collector result missing"
            }

        report.append(
            evaluate_control(name, rule, actual)
        )

    return report


def print_report(report, scan_id):

    print("\n===== SECURITY COMPLIANCE REPORT =====")
    print(f"Scan ID: {scan_id}\n")

    for item in report:

        print(f"Control: {item['control']}")
        print(f"Status: {item['status']}")
        print(f"Severity: {item['severity']}")
        print(f"Evidence: {item['evidence']}")
        print(f"Recommendation: {item['recommendation']}")
        print(f"Previous Status: {item['previous_status']}")
        print(f"Drift Status: {item['drift_status']}")
        print("-" * 50)

    passed = sum(
        item["status"] == "PASS"
        for item in report
    )

    failed = sum(
        item["status"] == "FAIL"
        for item in report
    )

    errors = sum(
        item["status"] == "ERROR"
        for item in report
    )

    total = len(report)

    # Exclude ERROR controls from the compliance denominator.
    assessed = passed + failed

    score = (
        passed / assessed * 100
        if assessed else 0
    )

    drift_count = sum(
        item["drift_status"] == "DRIFT_DETECTED"
        for item in report
    )

    print("\n===== SUMMARY =====")
    print(f"Total Controls: {total}")
    print(f"Assessed Controls: {assessed}")
    print(f"Compliance Score: {score:.1f}%")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Errors: {errors}")
    print(f"Drift Detected: {drift_count}")


if __name__ == "__main__":

    import sys

    project_root = BASE_DIR.parent
    sys.path.insert(0, str(project_root))

    from collectors.windows_collector import collect_all
    from compliance.storage import save_scan

    # Collect Windows security configuration
    results = collect_all()

    # Evaluate all 15 controls
    report = evaluate_all(results)

    # Save scan and detect configuration drift
    scan_id, updated_report = save_scan(report)

    # Display compliance report
    print_report(updated_report, scan_id)
