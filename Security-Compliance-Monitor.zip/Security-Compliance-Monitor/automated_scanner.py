
import logging
from pathlib import Path
from datetime import datetime
from compliance.alerts import check_security_alerts
from collectors.windows_collector import collect_all
from compliance.engine import evaluate_all
from compliance.storage import save_scan


# Project directories
BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "reports"

LOG_DIR.mkdir(exist_ok=True)

LOG_FILE = LOG_DIR / "automated_scans.log"


# Configure logging
logging.basicConfig(
    filename=str(LOG_FILE),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    encoding="utf-8"
)


def run_automated_scan():

    logging.info("Automated security scan started")

    try:

        # Step 1: Collect real Windows security settings
        scan_results = collect_all()

        # Step 2: Evaluate against security baseline
        report = evaluate_all(scan_results)

        # Step 3: Save scan and detect configuration drift
        scan_id, updated_report = save_scan(report)
        # Check security findings and send desktop notifications
        check_security_alerts(updated_report)
        # Step 4: Calculate scan summary
        passed = sum(
            item["status"] == "PASS"
            for item in updated_report
        )

        failed = sum(
            item["status"] == "FAIL"
            for item in updated_report
        )

        errors = sum(
            item["status"] == "ERROR"
            for item in updated_report
        )

        drift = sum(
            item["drift_status"] == "DRIFT_DETECTED"
            for item in updated_report
        )

        total = len(updated_report)

        score = (
            passed / total * 100
            if total else 0
        )

        # Step 5: Record scan summary
        logging.info(
            "Scan ID: %s | Passed: %s | Failed: %s | "
            "Errors: %s | Drift: %s | Score: %.1f%%",
            scan_id,
            passed,
            failed,
            errors,
            drift,
            score
        )

        print("\n===== AUTOMATED SECURITY SCAN =====")
        print(f"Scan ID: {scan_id}")
        print(f"Time: {datetime.now().astimezone().isoformat()}")
        print(f"Compliance Score: {score:.1f}%")
        print(f"Passed: {passed}")
        print(f"Failed: {failed}")
        print(f"Errors: {errors}")
        print(f"New Drift Events: {drift}")

        logging.info("Automated security scan completed")

        return True

    except Exception:
        logging.exception("Automated security scan failed")
        print("Scan failed. Check reports/automated_scans.log")
        return False


if __name__ == "__main__":
    run_automated_scan()
