
import sys
import sqlite3
import csv

from pathlib import Path
from datetime import datetime
from xml.sax.saxutils import escape

# Locate the main project directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Add the project root to Python's import path
sys.path.insert(0, str(BASE_DIR))

# Import framework mapping
from compliance.frameworks import get_control_mapping

# Database and report directories
DB_PATH = BASE_DIR / "compliance.db"
REPORT_DIR = BASE_DIR / "reports"

REPORT_DIR.mkdir(exist_ok=True)

# Keep your existing ReportLab imports below
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle
)


# Project paths
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "compliance.db"
REPORT_DIR = BASE_DIR / "reports"

REPORT_DIR.mkdir(exist_ok=True)



def get_latest_scan():
    """Retrieve the latest scan and its control results."""

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        scan = conn.execute("""
            SELECT *
            FROM scans
            ORDER BY scan_id DESC
            LIMIT 1
        """).fetchone()

        if scan is None:
            raise ValueError(
                "No scan data found. Run a security scan first."
            )

        results = conn.execute("""
            SELECT *
            FROM control_results
            WHERE scan_id = ?
            ORDER BY result_id
        """, (scan["scan_id"],)).fetchall()

    # Convert SQLite rows into dictionaries
    results = [dict(item) for item in results]

    # Attach framework mappings
    for item in results:
        item["framework_mapping"] = get_control_mapping(
            item["control"]
        )

    return scan, results


def calculate_summary(results):
    total = len(results)

    passed = sum(r["status"] == "PASS" for r in results)
    failed = sum(r["status"] == "FAIL" for r in results)
    errors = sum(r["status"] == "ERROR" for r in results)

    score = (passed / total * 100) if total else 0

    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "errors": errors,
        "score": round(score, 2)
    }


def format_framework_controls(controls):
    """Convert framework references into readable text."""

    return "; ".join(
        f"{item['id']} - {item['name']}"
        for item in controls
    ) or "Not mapped"



def generate_csv(scan, results, summary):
    """Generate a CSV compliance report."""

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output = REPORT_DIR / f"compliance_report_{timestamp}.csv"

    fields = [
        "Scan ID",
        "Scan Date",
        "Compliance Score",
        "Control",
        "Status",
        "Severity",
        "Evidence",
        "Recommendation",
        "Previous Status",
        "Drift Status",
        "CIS Controls",
        "NIST Controls",
        "ISO 27001 Controls"
    ]

    with open(output, "w", newline="", encoding="utf-8-sig") as file:

        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()

        for item in results:
            writer.writerow({
    "Scan ID": scan["scan_id"],
    "Scan Date": scan["scan_time"],
    "Compliance Score": summary["score"],
    "Control": item["control"],
    "Status": item["status"],
    "Severity": item["severity"],
    "Evidence": item["evidence"],
    "Recommendation": item["recommendation"],
    "Previous Status": item["previous_status"],
    "Drift Status": item["drift_status"],

    "CIS Controls": format_framework_controls(
        item["framework_mapping"]["cis_controls"]
    ),

    "NIST Controls": format_framework_controls(
        item["framework_mapping"]["nist_controls"]
    ),

    "ISO 27001 Controls": format_framework_controls(
        item["framework_mapping"]["iso_controls"]
    )
})

    return output


def generate_pdf(scan, results, summary):
    """Generate a professional PDF compliance report."""

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output = REPORT_DIR / f"compliance_report_{timestamp}.pdf"

    doc = SimpleDocTemplate(
        str(output),
        pagesize=landscape(A4),
        rightMargin=15 * mm,
        leftMargin=15 * mm,
        topMargin=15 * mm,
        bottomMargin=15 * mm
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Title"],
        fontSize=20,
        alignment=TA_CENTER,
        spaceAfter=12
    )

    normal = styles["BodyText"]

    small = ParagraphStyle(
        "SmallText",
        parent=normal,
        fontSize=7,
        leading=9,
        wordWrap="CJK"
    )

    story = []

    story.append(Paragraph(
        "SECURITY COMPLIANCE REPORT",
        title_style
    ))

    story.append(Paragraph(
        "Continuous Security Policy Compliance & Drift Monitor",
        ParagraphStyle(
            "Subtitle",
            parent=normal,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#475569")
        )
    ))

    story.append(Spacer(1, 20))

    story.append(Paragraph(
        f"<b>Scan ID:</b> {scan['scan_id']}<br/>"
        f"<b>Scan Date:</b> {escape(str(scan['scan_time']))}<br/>"
        f"<b>Report Generated:</b> {datetime.now().astimezone().isoformat()}",
        normal
    ))

    story.append(Spacer(1, 20))

    summary_data = [
        ["Total Controls", "Passed", "Failed", "Errors", "Compliance Score"],
        [
            str(summary["total"]),
            str(summary["passed"]),
            str(summary["failed"]),
            str(summary["errors"]),
            f"{summary['score']}%"
        ]
    ]

    summary_table = Table(
        summary_data,
        colWidths=[45 * mm] * 5
    )

    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0),
         colors.HexColor("#172554")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("BACKGROUND", (0, 1), (-1, 1),
         colors.HexColor("#E2E8F0")),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.white),
        ("PADDING", (0, 0), (-1, -1), 9)
    ]))

    story.append(summary_table)
    story.append(Spacer(1, 22))

    story.append(Paragraph(
        "<b>Detailed Security Control Results</b>",
        styles["Heading2"]
    ))

    headers = [
    "Control",
    "Status",
    "Severity",
    "Evidence",
    "Recommendation",
    "Previous",
    "Drift",
    "CIS",
    "NIST",
    "ISO 27001"
]
    
    table_data = [[
        Paragraph(f"<b>{h}</b>", small)
        for h in headers
    ]]

    for item in results:
        table_data.append([
    Paragraph(escape(str(item["control"])), small),
    Paragraph(escape(str(item["status"])), small),
    Paragraph(escape(str(item["severity"])), small),
    Paragraph(escape(str(item["evidence"] or "")), small),
    Paragraph(escape(str(item["recommendation"] or "")), small),
    Paragraph(escape(str(item["previous_status"] or "None")), small),
    Paragraph(escape(str(item["drift_status"] or "")), small),

    Paragraph(
        escape(format_framework_controls(
            item["framework_mapping"]["cis_controls"]
        )), small
    ),

    Paragraph(
        escape(format_framework_controls(
            item["framework_mapping"]["nist_controls"]
        )), small
    ),

    Paragraph(
        escape(format_framework_controls(
            item["framework_mapping"]["iso_controls"]
        )), small
    )
])

    detail_table = Table(
        table_data,
        colWidths=[
    22 * mm,
    14 * mm,
    15 * mm,
    35 * mm,
    50 * mm,
    17 * mm,
    22 * mm,
    18 * mm,
    18 * mm,
    20 * mm
],
        repeatRows=1
    )

    detail_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0),
         colors.HexColor("#172554")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5,
         colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 7),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.white, colors.HexColor("#F1F5F9")])
    ]))

    story.append(detail_table)
    story.append(Spacer(1, 20))

    story.append(Paragraph(
        "<b>Report Notes</b>",
        styles["Heading2"]
    ))

    story.append(Paragraph(
        "This report reflects the security controls implemented "
        "and evaluated by the local compliance monitoring prototype. "
        "A passing result does not establish complete system security "
        "or certify organizational compliance with any framework.",
        normal
    ))

    def add_page_number(canvas, document):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.drawRightString(
            landscape(A4)[0] - 15 * mm,
            8 * mm,
            f"Page {document.page}"
        )
        canvas.restoreState()

    doc.build(
        story,
        onFirstPage=add_page_number,
        onLaterPages=add_page_number
    )

    return output


def generate_reports():
    scan, results = get_latest_scan()
    summary = calculate_summary(results)

    csv_file = generate_csv(scan, results, summary)
    pdf_file = generate_pdf(scan, results, summary)

    print("\n===== REPORT GENERATION SUCCESSFUL =====")
    print(f"Scan ID: {scan['scan_id']}")
    print(f"Compliance Score: {summary['score']}%")
    print(f"Passed: {summary['passed']}")
    print(f"Failed: {summary['failed']}")
    print(f"Errors: {summary['errors']}")

    print(f"\nPDF Report: {pdf_file}")
    print(f"CSV Report: {csv_file}")


if __name__ == "__main__":
    generate_reports()
