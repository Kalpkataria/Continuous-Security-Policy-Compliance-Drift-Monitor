from compliance.alerts import send_alert

send_alert(
    "Security Compliance Monitor",
    "Your notification system is working successfully!",
    "info"
)