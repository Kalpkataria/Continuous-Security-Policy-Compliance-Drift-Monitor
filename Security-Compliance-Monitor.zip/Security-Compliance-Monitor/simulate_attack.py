
from compliance.alert_storage import save_alert

simulated_alerts = [
    {
        "control": "firewall",
        "alert_type": "Unauthorized Firewall Configuration Change",
        "severity": "Critical",
        "message": "SIMULATION: Unauthorized firewall configuration change detected. Potential exposure to unwanted network traffic."
    },
    {
        "control": "defender_antivirus",
        "alert_type": "Malware Detection",
        "severity": "Critical",
        "message": "SIMULATION: Suspicious malware detected on the endpoint. Immediate investigation is required."
    },
    {
        "control": "defender_realtime",
        "alert_type": "Real-Time Protection Disabled",
        "severity": "Critical",
        "message": "SIMULATION: Defender real-time protection appears disabled. Endpoint protection may be weakened."
    },
    {
        "control": "event_log",
        "alert_type": "Security Logging Failure",
        "severity": "High",
        "message": "SIMULATION: Windows Event Log service is unavailable. Security events may not be recorded."
    },
    {
        "control": "defender_antivirus",
        "alert_type": "Suspicious PowerShell Activity",
        "severity": "High",
        "message": "SIMULATION: Suspicious PowerShell activity detected. Investigate the command, process and user context."
    },
    {
        "control": "firewall",
        "alert_type": "Suspicious Outbound Connection",
        "severity": "High",
        "message": "SIMULATION: An endpoint attempted to communicate with an unusual external destination."
    },
    {
        "control": "event_log",
        "alert_type": "Repeated Failed Login Attempts",
        "severity": "Medium",
        "message": "SIMULATION: Multiple failed authentication attempts detected. Possible brute-force activity."
    },
    {
        "control": "defender_antivirus",
        "alert_type": "Potentially Unwanted Application",
        "severity": "Low",
        "message": "SIMULATION: A potentially unwanted application was identified for review."
    }
]

print("\n=== SECURITY INCIDENT SIMULATION ===")

for alert in simulated_alerts:
    save_alert(
        control=alert["control"],
        alert_type=alert["alert_type"],
        severity=alert["severity"],
        message=alert["message"]
    )

    print(
        f"[ALERT CREATED] {alert['severity']} - "
        f"{alert['alert_type']}"
    )

print("\n8 simulated security alerts created successfully.")
print("Refresh your dashboard to view them.")
