
from flask import (
    Flask,
    render_template,
    redirect,
    url_for,
    flash,
    send_file,
    request
)

import sqlite3

from compliance.frameworks import get_control_mapping
from compliance.alert_storage import (
    get_alert_history,
    update_alert_status
)
from compliance.engine import evaluate_all
from compliance.storage import (
    save_scan,
    DB_PATH,
    get_scan_history
)
from compliance.remediation import get_remediation
from collectors.windows_collector import collect_all

from reports.generate_reports import (
    get_latest_scan,
    calculate_summary,
    generate_pdf,
    generate_csv
)


app = Flask(__name__)
app.secret_key = "local-development-secret"


# --------------------------------------------------
# GET LATEST SCAN DATA
# --------------------------------------------------

def get_dashboard_data():

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        latest = conn.execute("""
            SELECT * FROM scans
            ORDER BY scan_id DESC
            LIMIT 1
        """).fetchone()

        if latest is None:
            return None, [], []

        scan_id = latest["scan_id"]

        results = conn.execute("""
            SELECT * FROM control_results
            WHERE scan_id = ?
            ORDER BY result_id
        """, (scan_id,)).fetchall()

        history = conn.execute("""
            SELECT * FROM scans
            ORDER BY scan_id DESC
            LIMIT 10
        """).fetchall()

    return latest, results, history


# --------------------------------------------------
# MAIN DASHBOARD
# --------------------------------------------------

@app.route("/")
def dashboard():

    latest, results, history = get_dashboard_data()

    # Convert database rows into dictionaries
    results = [dict(item) for item in results]

    # Attach framework mappings to every control
    for item in results:
        item["framework_mapping"] = get_control_mapping(
            item["control"]
        )

    # Calculate compliance statistics
    total = len(results)

    passed = sum(
        item["status"] == "PASS"
        for item in results
    )

    failed = sum(
        item["status"] == "FAIL"
        for item in results
    )

    errors = sum(
        item["status"] == "ERROR"
        for item in results
    )

    # Exclude ERROR controls from the compliance score
    assessed = passed + failed

    score = (
        passed / assessed * 100
        if assessed else 0
    )

    # Count configuration drift
    drift_count = sum(
        item["drift_status"] == "DRIFT_DETECTED"
        for item in results
    )

    # --------------------------------------------------
    # SECURITY ALERT HISTORY AND FILTERS
    # --------------------------------------------------

    selected_status = request.args.get("status", "")
    selected_severity = request.args.get("severity", "")

    alert_history = get_alert_history(
        limit=100,
        status=selected_status or None,
        severity=selected_severity or None
    )

    # Convert alert rows into dictionaries
    alert_history = [
        dict(alert)
        for alert in alert_history
    ]

    # Attach remediation guidance to every alert
    for alert in alert_history:

        alert["remediation"] = get_remediation(
            alert["control"],
            alert["severity"],
            alert["alert_type"]
        )

    # Get all recent alerts for overview cards
    all_alerts = get_alert_history(limit=1000)

    open_alerts = sum(
        alert["status"] == "OPEN"
        for alert in all_alerts
    )

    acknowledged_alerts = sum(
        alert["status"] == "ACKNOWLEDGED"
        for alert in all_alerts
    )

    resolved_alerts = sum(
        alert["status"] == "RESOLVED"
        for alert in all_alerts
    )

    critical_alerts = sum(
        alert["severity"] in ("Critical", "High")
        and alert["status"] != "RESOLVED"
        for alert in all_alerts
    )

    # Get previous scan history
    scan_history = get_scan_history(10)

    # Render dashboard
    return render_template(
        "index.html",

        latest=latest,
        results=results,
        history=history,

        total=total,
        assessed=assessed,
        passed=passed,
        failed=failed,
        errors=errors,
        score=round(score, 1),
        drift_count=drift_count,

        alert_history=alert_history,
        scan_history=scan_history,

        selected_status=selected_status,
        selected_severity=selected_severity,

        open_alerts=open_alerts,
        acknowledged_alerts=acknowledged_alerts,
        resolved_alerts=resolved_alerts,
        critical_alerts=critical_alerts
    )


# --------------------------------------------------
# RUN A NEW COMPLIANCE SCAN
# --------------------------------------------------

@app.route("/scan", methods=["POST"])
def run_scan():

    try:
        # Collect Windows security configuration
        scan_results = collect_all()

        # Evaluate all 15 baseline controls
        report = evaluate_all(scan_results)

        # Save scan and detect configuration drift
        scan_id, updated_report = save_scan(report)

        flash(
            f"Scan #{scan_id} completed successfully.",
            "success"
        )

    except Exception as error:

        flash(
            f"Scan failed: {error}",
            "danger"
        )

    return redirect(url_for("dashboard"))


# --------------------------------------------------
# ACKNOWLEDGE SECURITY ALERT
# --------------------------------------------------

@app.route(
    "/alerts/<int:alert_id>/acknowledge",
    methods=["POST"]
)
def acknowledge_alert(alert_id):

    updated = update_alert_status(
        alert_id,
        "ACKNOWLEDGED"
    )

    if updated:
        flash(
            "Alert acknowledged successfully.",
            "success"
        )
    else:
        flash(
            "Alert not found.",
            "danger"
        )

    return redirect(url_for("dashboard"))


# --------------------------------------------------
# RESOLVE SECURITY ALERT
# --------------------------------------------------

@app.route(
    "/alerts/<int:alert_id>/resolve",
    methods=["POST"]
)
def resolve_alert(alert_id):

    updated = update_alert_status(
        alert_id,
        "RESOLVED"
    )

    if updated:
        flash(
            "Alert resolved successfully.",
            "success"
        )
    else:
        flash(
            "Alert not found.",
            "danger"
        )

    return redirect(url_for("dashboard"))


# --------------------------------------------------
# DOWNLOAD PDF REPORT
# --------------------------------------------------

@app.route("/download/pdf")
def download_pdf():

    try:
        scan, results = get_latest_scan()

        summary = calculate_summary(results)

        file_path = generate_pdf(
            scan,
            results,
            summary
        )

        return send_file(
            file_path,
            as_attachment=True,
            download_name="Security_Compliance_Report.pdf"
        )

    except Exception as error:

        return (
            f"PDF generation failed: {error}",
            500
        )


# --------------------------------------------------
# DOWNLOAD CSV REPORT
# --------------------------------------------------

@app.route("/download/csv")
def download_csv():

    try:
        scan, results = get_latest_scan()

        summary = calculate_summary(results)

        file_path = generate_csv(
            scan,
            results,
            summary
        )

        return send_file(
            file_path,
            as_attachment=True,
            download_name="Security_Compliance_Report.csv"
        )

    except Exception as error:

        return (
            f"CSV generation failed: {error}",
            500
        )


# --------------------------------------------------
# START FLASK APPLICATION
# --------------------------------------------------

if __name__ == "__main__":

    app.run(debug=True)
