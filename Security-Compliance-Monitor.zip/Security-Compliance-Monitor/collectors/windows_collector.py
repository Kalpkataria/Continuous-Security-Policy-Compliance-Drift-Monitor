
import subprocess
import json


def run_powershell(command):
    """
    Execute a read-only PowerShell query.
    Returns parsed JSON data or an error.
    """
    try:
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                command
            ],
            capture_output=True,
            text=True,
            timeout=20,
            check=False
        )

        if result.returncode != 0:
            return {
                "status": "ERROR",
                "evidence": result.stderr.strip() or "PowerShell query failed"
            }

        output = result.stdout.strip()

        if not output:
            return {
                "status": "ERROR",
                "evidence": "No data returned"
            }

        return {
            "status": "OK",
            "data": json.loads(output)
        }

    except subprocess.TimeoutExpired:
        return {
            "status": "ERROR",
            "evidence": "PowerShell query timed out"
        }

    except json.JSONDecodeError:
        return {
            "status": "ERROR",
            "evidence": "Could not parse PowerShell output"
        }

    except Exception as exc:
        return {
            "status": "ERROR",
            "evidence": str(exc)
        }


def collect_firewall_status():
    return run_powershell("""
        Get-NetFirewallProfile |
        Select-Object Name, Enabled |
        ConvertTo-Json -Compress
    """)


def collect_defender_antivirus():
    return run_powershell("""
        Get-MpComputerStatus |
        Select-Object AntivirusEnabled |
        ConvertTo-Json -Compress
    """)


def collect_defender_realtime():
    return run_powershell("""
        Get-MpComputerStatus |
        Select-Object RealTimeProtectionEnabled |
        ConvertTo-Json -Compress
    """)


def collect_event_log():
    return run_powershell("""
        Get-Service -Name EventLog |
        Select-Object @{Name='Status';Expression={$_.Status.ToString()}} |
        ConvertTo-Json -Compress
    """)


def collect_uac():
    return run_powershell("""
        $value = Get-ItemPropertyValue `
            -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' `
            -Name EnableLUA -ErrorAction Stop

        ConvertTo-Json -InputObject ([int]$value) -Compress
    """)


def collect_guest_account():
    return run_powershell("""
        $account = Get-LocalUser -Name 'Guest' -ErrorAction Stop
        ConvertTo-Json -InputObject ([bool](-not $account.Enabled)) -Compress
    """)


def collect_smbv1():
    return run_powershell("""
        $config = Get-SmbServerConfiguration -ErrorAction Stop
        ConvertTo-Json -InputObject ([bool](-not $config.EnableSMB1Protocol)) -Compress
    """)


def collect_windows_update():
    return run_powershell("""
        $service = Get-CimInstance Win32_Service `
            -Filter "Name='wuauserv'" -ErrorAction Stop

        ConvertTo-Json -InputObject ([bool]($service.StartMode -ne 'Disabled')) -Compress
    """)


def collect_automatic_updates():
    return run_powershell("""
        $path = 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU'

        try {
            $value = Get-ItemPropertyValue `
                -Path $path -Name AUOptions -ErrorAction Stop

            ConvertTo-Json -InputObject ([int]$value) -Compress
        }
        catch {
            throw 'Automatic Updates policy is not configured or accessible.'
        }
    """)


def collect_powershell_logging():
    return run_powershell("""
        $path = 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging'

        try {
            $value = Get-ItemPropertyValue `
                -Path $path -Name EnableScriptBlockLogging -ErrorAction Stop

            ConvertTo-Json -InputObject ([bool]($value -eq 1)) -Compress
        }
        catch {
            ConvertTo-Json -InputObject $false -Compress
        }
    """)


def collect_audit_policy():
    return run_powershell("""
        $output = auditpol.exe /get /subcategory:"Logon" /r 2>&1

        if ($LASTEXITCODE -ne 0) {
            throw 'Could not read Logon audit policy.'
        }

        ConvertTo-Json -InputObject ($output -join "`n") -Compress
    """)


def collect_remote_desktop():
    return run_powershell("""
        $value = Get-ItemPropertyValue `
            -Path 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server' `
            -Name fDenyTSConnections -ErrorAction Stop

        ConvertTo-Json -InputObject ([bool]($value -eq 1)) -Compress
    """)


def collect_screen_lock():
    return run_powershell("""
        $path = 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System'

        try {
            $value = Get-ItemPropertyValue `
                -Path $path -Name InactivityTimeoutSecs -ErrorAction Stop

            ConvertTo-Json -InputObject ([int]$value) -Compress
        }
        catch {
            throw 'Machine inactivity timeout policy is not configured.'
        }
    """)


def collect_password_length():
    return run_powershell("""
        $output = net.exe accounts

        if ($LASTEXITCODE -ne 0) {
            throw 'Could not read password policy.'
        }

        $match = $output | Select-String 'Minimum password length'

        if (-not $match) {
            throw 'Minimum password length was not found.'
        }

        $number = [regex]::Match($match.Line, '\\d+')

        if (-not $number.Success) {
            throw 'Could not parse minimum password length.'
        }

        ConvertTo-Json -InputObject ([int]$number.Value) -Compress
    """)


def collect_lockout_threshold():
    return run_powershell("""
        $output = net.exe accounts

        if ($LASTEXITCODE -ne 0) {
            throw 'Could not read account lockout policy.'
        }

        $match = $output | Select-String 'Lockout threshold'

        if (-not $match) {
            throw 'Account lockout threshold was not found.'
        }

        $number = [regex]::Match($match.Line, '\\d+')

        if (-not $number.Success) {
            throw 'Could not parse account lockout threshold.'
        }

        ConvertTo-Json -InputObject ([int]$number.Value) -Compress
    """)


def normalize_firewall(result):
    """Normalize firewall profiles into a list."""

    if result["status"] != "OK":
        return result

    profiles = result["data"]

    if isinstance(profiles, dict):
        profiles = [profiles]

    for profile in profiles:
        profile["Enabled"] = (
            str(profile.get("Enabled")).lower() in ("true", "1")
        )

    return {
        "status": "OK",
        "data": profiles
    }


def collect_all():
    """
    Collect 15 Windows security configuration settings.

    All queries are read-only.
    """

    results = {
        "firewall": normalize_firewall(collect_firewall_status()),

        "defender_antivirus": collect_defender_antivirus(),

        "defender_realtime": collect_defender_realtime(),

        "event_log": collect_event_log(),

        "uac": collect_uac(),

        "guest_account": collect_guest_account(),

        "smbv1": collect_smbv1(),

        "windows_update": collect_windows_update(),

        "automatic_updates": collect_automatic_updates(),

        "powershell_logging": collect_powershell_logging(),

        "audit_policy": collect_audit_policy(),

        "remote_desktop": collect_remote_desktop(),

        "screen_lock": collect_screen_lock(),

        "password_length": collect_password_length(),

        "lockout_threshold": collect_lockout_threshold()
    }

    return results


if __name__ == "__main__":

    print("\nWINDOWS SECURITY CONFIGURATION COLLECTOR")
    print("=" * 50)

    results = collect_all()

    for control, result in results.items():

        print(f"\nControl: {control}")
        print(f"Collection status: {result['status']}")

        if result["status"] == "OK":
            print(f"Collected value: {result['data']}")
        else:
            print(f"Evidence: {result['evidence']}")
